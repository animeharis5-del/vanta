import asyncio
import json
import html
import logging
import random
import re
import time
import zipfile
from datetime import datetime
from pathlib import Path

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.error import TelegramError, BadRequest
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes,
)

# IMPORT DARI cek_wait.py — TIDAK DIUBAH
from cek_wait import detect, fmt, ARTI_REASON, CekBapaklu, versi_mark

import config
import rich_ui

# ==================== LOGGING ====================
logging.basicConfig(
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logging.getLogger("telegram").setLevel(logging.WARNING)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
logging.getLogger("telegram.ext").setLevel(logging.WARNING)

logger = logging.getLogger("bot")

BASE_DIR = Path(__file__).parent
STATS_PATH = BASE_DIR / config.STATS_FILE
PREMIUM_PATH = BASE_DIR / config.PREMIUM_FILE
BANNED_PATH = BASE_DIR / config.BANNED_FILE

_cooldown_tracker = {}
_detect_semaphore = asyncio.Semaphore(3)


# ==================== HELPER KIRIM PESAN ====================

# Konversi emoji yang tersedia di pack pengguna menjadi Telegram Premium Custom Emoji.
# Tombol inline dan callback alert tetap Unicode karena Bot API tidak mendukung entity di sana.
_EMOJI_MAP = getattr(config, "TG_EMOJI_MAP", {}) or {}
_EMOJI_PATTERN = re.compile("|".join(re.escape(e) for e in sorted(_EMOJI_MAP, key=len, reverse=True))) if _EMOJI_MAP else None


def _customize_emojis(text: str):
    if not isinstance(text, str) or not _EMOJI_PATTERN:
        return text, False

    # Jangan mengubah emoji di tag custom yang sudah ada atau di blok pre/code.
    protected = []
    def protect(match):
        protected.append(match.group(0))
        return f"VANTAPROTECTEDBLOCK{len(protected)-1}END"

    text = re.sub(r"<tg-emoji\b[^>]*>.*?</tg-emoji>", protect, text, flags=re.S | re.I)
    text = re.sub(r"<(pre|code)\b[^>]*>.*?</\1\s*>", protect, text, flags=re.S | re.I)

    changed = False
    def replace(match):
        nonlocal changed
        emoji = match.group(0)
        emoji_id = str(_EMOJI_MAP.get(emoji, "")).strip()
        if emoji_id.isdigit():
            changed = True
            return f'<tg-emoji emoji-id="{emoji_id}">{emoji}</tg-emoji>'
        return emoji

    # Proses teks di antara tag HTML saja agar nama tag/atribut tidak tersentuh.
    parts = re.split(r"(<[^>]+>)", text)
    in_tag = False
    for i, part in enumerate(parts):
        if part.startswith("<") and part.endswith(">"):
            continue
        parts[i] = _EMOJI_PATTERN.sub(replace, part)
    text = "".join(parts)
    for i, block in enumerate(protected):
        text = text.replace(f"VANTAPROTECTEDBLOCK{i}END", block)
    return text, changed


def _strip_custom_emoji(text):
    """Buang tag <tg-emoji> tapi pertahankan emoji Unicode-nya (jaring pengaman)."""
    if not isinstance(text, str):
        return text
    return re.sub(r"<tg-emoji\b[^>]*>(.*?)</tg-emoji>", r"\1", text,
                  flags=re.S | re.I)


def _entity_error(e):
    return "entit" in str(e).lower()

async def balas(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, **kwargs):
    text, changed = _customize_emojis(text)
    if changed:
        kwargs["parse_mode"] = "HTML"
    async def _kirim(t):
        if update.effective_message:
            return await update.effective_message.reply_text(t, **kwargs)
        elif update.effective_chat:
            return await context.bot.send_message(chat_id=update.effective_chat.id, text=t, **kwargs)
        return None

    try:
        return await _kirim(text)
    except BadRequest as e:
        if not _entity_error(e):
            raise
        logger.warning("Entity ditolak, kirim ulang tanpa custom emoji: %s", e)
        return await _kirim(_strip_custom_emoji(text))


async def balas_foto(update: Update, context: ContextTypes.DEFAULT_TYPE,
                     photo: str, caption: str = None, **kwargs):
    caption, changed = _customize_emojis(caption)
    if changed:
        kwargs["parse_mode"] = "HTML"
    async def _kirim(cap):
        if update.effective_message:
            return await update.effective_message.reply_photo(photo=photo, caption=cap, **kwargs)
        elif update.effective_chat:
            return await context.bot.send_photo(chat_id=update.effective_chat.id, photo=photo,
                                                caption=cap, **kwargs)
        return None

    try:
        return await _kirim(caption)
    except BadRequest as e:
        if not _entity_error(e):
            raise
        logger.warning("Entity caption ditolak, kirim ulang tanpa custom emoji: %s", e)
        return await _kirim(_strip_custom_emoji(caption))


async def aman_answer(query, text: str = None, show_alert: bool = False):
    try:
        if text:
            await query.answer(text, show_alert=show_alert)
        else:
            await query.answer()
    except TelegramError as e:
        logger.warning("Gagal answer query: %s", e)


async def kirim_atau_edit(query, teks, keyboard, keyboard_rich=None):
    # Menu HTML mendukung Telegram Premium Custom Emoji (<tg-emoji>).
    isi, _ = _customize_emojis(teks)
    try:
        if query.message.caption is not None:
            # Caption foto: Rich Message tak didukung -> fallback HTML.
            await query.edit_message_caption(
                caption=rich_ui.rich_ke_html(isi), parse_mode="HTML",
                reply_markup=keyboard)
        else:
            # Coba Rich Message dulu, fallback ke HTML standar.
            if keyboard_rich and rich_ui.ada_tag_rich(isi):
                ok = await rich_ui.edit_rich(
                    config.BOT_TOKEN, query.message.chat.id,
                    query.message.message_id, isi, keyboard_rich)
                if ok:
                    return
            await query.edit_message_text(
                text=rich_ui.rich_ke_html(isi), parse_mode="HTML",
                reply_markup=keyboard)
    except BadRequest as e:
        if "not modified" in str(e).lower():
            return
        if _entity_error(e):
            logger.warning("Entity ditolak saat edit, ulangi tanpa custom emoji: %s", e)
            try:
                polos = _strip_custom_emoji(rich_ui.rich_ke_html(isi))
                if query.message.caption is not None:
                    await query.edit_message_caption(
                        caption=polos, parse_mode="HTML", reply_markup=keyboard)
                else:
                    await query.edit_message_text(
                        text=polos, parse_mode="HTML", reply_markup=keyboard)
            except TelegramError as e2:
                logger.warning("Gagal edit (retry): %s", e2)
            return
        logger.warning("Gagal edit: %s", e)
    except TelegramError as e:
        logger.warning("Gagal edit: %s", e)


# ==================== DATABASE ====================

def _load_json(path: Path, default: dict) -> dict:
    if path.exists():
        try:
            return json.loads(path.read_text())
        except Exception:
            pass
    return default


def _save_json(path: Path, data: dict):
    try:
        path.write_text(json.dumps(data, indent=2))
    except Exception as e:
        logger.error("Gagal simpan %s: %s", path, e)


def load_stats() -> dict:
    return _load_json(STATS_PATH, {"users": {}, "global": {"total_users": 0, "total_detections": 0}})


def save_stats(data: dict):
    _save_json(STATS_PATH, data)


def load_premium() -> dict:
    return _load_json(PREMIUM_PATH, {"users": {}})


def save_premium(data: dict):
    _save_json(PREMIUM_PATH, data)


def load_banned() -> dict:
    return _load_json(BANNED_PATH, {"users": {}})


def save_banned(data: dict):
    _save_json(BANNED_PATH, data)


def is_premium(user_id: int) -> bool:
    if config.OWNER_ID is not None:
        try:
            if user_id == int(config.OWNER_ID):
                return True
        except (TypeError, ValueError):
            pass
    data = load_premium()
    return str(user_id) in data.get("users", {})


def is_banned(user_id: int) -> dict | None:
    data = load_banned()
    return data.get("users", {}).get(str(user_id))


def is_owner(user_id: int) -> bool:
    if config.OWNER_ID is None:
        return False
    try:
        return user_id == int(config.OWNER_ID)
    except (TypeError, ValueError):
        return False


# ==================== USER TIER ====================

def cek_tier(user_id: int) -> str:
    return "premium" if is_premium(user_id) else "biasa"


def ambil_setting(user_id: int) -> dict:
    tier = cek_tier(user_id)
    if tier == "premium":
        return dict(config.USER_PREMIUM, tier="premium")
    return dict(config.USER_BIASA, tier="biasa")


def sisa_cooldown(user_id: int) -> int:
    setting = ambil_setting(user_id)
    cd = setting.get("cooldown", 0)
    if cd <= 0:
        return 0
    terakhir = _cooldown_tracker.get(user_id, 0)
    return max(0, int(cd - (time.time() - terakhir)))


def tandai_cooldown(user_id: int):
    _cooldown_tracker[user_id] = time.time()


# ==================== STATISTIK ====================

def update_stats(user_id: int, username: str, count: int = 1):
    data = load_stats()
    today = datetime.now().strftime("%Y-%m-%d")
    uid = str(user_id)

    if uid not in data["users"]:
        data["users"][uid] = {
            "username": username,
            "total_detections": 0,
            "today_detections": 0,
            "last_date": today,
        }
        data["global"]["total_users"] += 1

    u = data["users"][uid]
    u["username"] = username
    if u.get("last_date") != today:
        u["today_detections"] = 0
        u["last_date"] = today

    u["total_detections"] += count
    u["today_detections"] += count
    data["global"]["total_detections"] += count
    save_stats(data)


def get_stats(user_id: int) -> dict:
    data = load_stats()
    u = data["users"].get(str(user_id), {
        "username": "-", "total_detections": 0, "today_detections": 0,
    })
    return {
        "username": u.get("username", "-"),
        "total": u.get("total_detections", 0),
        "today": u.get("today_detections", 0),
        "global_users": data["global"].get("total_users", 0),
        "global_detections": data["global"].get("total_detections", 0),
    }


# ==================== UTIL ====================

def valid_nomor(teks: str) -> bool:
    return len(re.sub(r"\D", "", teks)) >= 8


def owner_only(func):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if config.OWNER_ID is not None:
            try:
                oid = int(config.OWNER_ID)
            except (TypeError, ValueError):
                oid = config.OWNER_ID
            if update.effective_user.id != oid:
                if update.callback_query:
                    await aman_answer(update.callback_query, "⛔ Khusus owner!", show_alert=True)
                else:
                    await balas(update, context, "⛔ Khusus owner.")
                return
        return await func(update, context)
    return wrapper


def banned_guard(func):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        user = update.effective_user
        if user:
            info = is_banned(user.id)
            if info:
                alasan = info.get("reason") or "tidak ada alasan"
                teks = (
                    f"🚫 Anda di-ban oleh owner.\n\n"
                    f"Alasan: {alasan}\n"
                    f"Sejak: {info.get('since', '-')}"
                )
                if update.callback_query:
                    await aman_answer(update.callback_query, "🚫 Anda dibanned.", show_alert=True)
                else:
                    await balas(update, context, teks)
                return
        return await func(update, context)
    return wrapper


def detik_ke_teks(d) -> str:
    try:
        d = int(d)
    except (TypeError, ValueError):
        return "-"
    if d <= 0:
        return "siap"
    jam, sisa = divmod(d, 3600)
    menit, detik = divmod(sisa, 60)
    parts = []
    if jam:
        parts.append(f"{jam}j")
    if menit or jam:
        parts.append(f"{menit}m")
    parts.append(f"{detik}s")
    return " ".join(parts)


REASON_NGAMBEK = (
    "temporarily_unavailable",
    "too_many_requests",
    "rate_limit",
    "rate_limited",
    "server_busy",
    "try_again_later",
)


def klasifikasi(r: dict) -> dict:
    if not isinstance(r, dict):
        return {"kategori": "error", "cooldown_detik": None, "alasan": "invalid respon"}

    status, reason = r.get("status"), r.get("reason")
    appeal = r.get("appeal_token")

    if status == "fail" and appeal:
        return {"kategori": "banned", "cooldown_detik": None, "alasan": "Terbanned WA"}

    if reason and reason.lower() in REASON_NGAMBEK:
        return {"kategori": "ngambek", "cooldown_detik": None, "alasan": reason}

    if reason == "blocked" and not appeal:
        return {"kategori": "clone", "cooldown_detik": None, "alasan": "gak support clone"}

    if status == "invalid":
        return {"kategori": "tidak_dapat_otp", "cooldown_detik": None,
                "alasan": r.get("reason") or "nomor invalid"}

    if reason in ("no_routes", "incorrect"):
        return {"kategori": "tidak_dapat_otp", "cooldown_detik": None, "alasan": reason}

    if reason in ("bad_token", "old_version"):
        return {"kategori": "error", "cooldown_detik": None, "alasan": reason}

    sms_wait = r.get("sms_wait")
    if isinstance(sms_wait, (int, float)) and not isinstance(sms_wait, bool):
        if sms_wait <= 0:
            return {"kategori": "siap", "cooldown_detik": 0, "alasan": None}
        return {"kategori": "cooldown", "cooldown_detik": int(sms_wait), "alasan": None}

    return {"kategori": "error", "cooldown_detik": None, "alasan": reason or "unknown"}


async def cek_satu_nomor_ringkas(nomor: str, methods: list) -> dict:
    hasil = {"nomor": nomor, "kategori": "error", "cooldown_detik": None, "alasan": None}
    ada_respons = False

    for method in methods:
        for attempt in range(3):
            try:
                r, _info = await detect(nomor, method)
                ada_respons = True
            except CekBapaklu as e:
                hasil["alasan"] = f"HTTP: {str(e)[:50]}"
                continue
            except asyncio.TimeoutError:
                hasil["alasan"] = "timeout"
                continue
            except Exception as e:
                hasil["alasan"] = f"{type(e).__name__}: {str(e)[:40]}"
                continue

            k = klasifikasi(r)

            if k["kategori"] == "ngambek" and attempt < 2:
                await asyncio.sleep(1.5 * (attempt + 1))
                continue

            if k["kategori"] in ("siap", "cooldown", "banned", "clone", "ngambek"):
                hasil.update(k)
                return hasil
            if k["kategori"] == "tidak_dapat_otp":
                hasil["kategori"] = "tidak_dapat_otp"
                hasil["alasan"] = k["alasan"]
                break
            if k["kategori"] == "error":
                hasil["alasan"] = f"reason: {r.get('reason') or 'unknown'}"
                break

    if not ada_respons:
        hasil["kategori"] = "clone"
        hasil["alasan"] = "gak support clone"

    return hasil


def susun_pesan(hasil_list, durasi, selesai=True, progress=None) -> str:
    siap = [h for h in hasil_list if h["kategori"] == "siap"]
    cooldown = [h for h in hasil_list if h["kategori"] == "cooldown"]
    banned = [h for h in hasil_list if h["kategori"] == "banned"]
    clone = [h for h in hasil_list if h["kategori"] == "clone"]
    ngambek = [h for h in hasil_list if h["kategori"] == "ngambek"]
    tidak_otp = [h for h in hasil_list if h["kategori"] == "tidak_dapat_otp"]
    error = [h for h in hasil_list if h["kategori"] == "error"]

    cooldown.sort(key=lambda h: h.get("cooldown_detik") or 0)

    def wrap_nomor(n):
        return f"<code>{html.escape(str(n))}</code>"

    parts = [rich_ui.rich_h2(f"{tgemoji('detek', '🔍')} HASIL DETEKSI")]

    # Ringkasan semua kategori
    parts.append(rich_ui.rich_info_table([
        [f"{tgemoji('success', '✅')} Siap OTP",
         rich_ui.rich_highlight(f"<b>{len(siap)}</b>")],
        [f"{tgemoji('clock', '⏱')} Cooldown", f"<b>{len(cooldown)}</b>"],
        [f"{tgemoji('failed', '❌')} Terbanned", f"<b>{len(banned)}</b>"],
        [f"{tgemoji('nootp', '🚫')} Tidak dapat OTP",
         f"<b>{len(tidak_otp)}</b>"],
        [f"{tgemoji('users', '👥')} Gak support clone", f"<b>{len(clone)}</b>"],
        [f"{tgemoji('warning', '⚠️')} Ngambek", f"<b>{len(ngambek)}</b>"],
        [f"{tgemoji('warning', '⚠️')} Error", f"<b>{len(error)}</b>"],
    ]))

    # Catatan cooldown -> blok lipat
    parts.append(rich_ui.rich_fold(
        f"{tgemoji('warning', '⚠️')} Catatan cooldown",
        rich_ui.rich_para("Waktu cooldown bisa berubah sewaktu-waktu. "
                          "Segera login ke nomor yang telah melakukan detek.")))

    if siap:
        parts.append(rich_ui.rich_para(
            f"{tgemoji('success', '✅')} <b>Nomor siap OTP</b>"))
        parts.append(rich_ui.rich_data_table(
            ["Nomor"], [[wrap_nomor(h["nomor"])] for h in siap]))

    if cooldown:
        parts.append(rich_ui.rich_para(
            f"{tgemoji('clock', '⏱')} <b>Nomor yang sedang cooldown</b>"))
        parts.append(rich_ui.rich_data_table(
            ["Nomor", "Sisa"],
            [[wrap_nomor(h["nomor"]),
              detik_ke_teks(h["cooldown_detik"])] for h in cooldown]))

    if banned:
        parts.append(rich_ui.rich_para(
            f"{tgemoji('failed', '❌')} "
            "<b>Nomor yang tidak dapat menerima OTP</b>"))
        parts.append(rich_ui.rich_para("Terbanned WA"))
        parts.append(rich_ui.rich_data_table(
            ["Nomor", "Status"],
            [[wrap_nomor(h["nomor"]),
              f"{tgemoji('failed', '❌')} Banned"] for h in banned]))

    if tidak_otp:
        parts.append(rich_ui.rich_para(
            f"{tgemoji('nootp', '🚫')} <b>Tidak terdaftar / no routes</b>"))
        parts.append(rich_ui.rich_data_table(
            ["Nomor", "Alasan"],
            [[wrap_nomor(h["nomor"]),
              html.escape(str(h.get("alasan") or "-"))] for h in tidak_otp]))

    if clone:
        parts.append(rich_ui.rich_para(
            f"{tgemoji('users', '👥')} <b>Gak Support Clone</b>"))
        parts.append(rich_ui.rich_data_table(
            ["Nomor"], [[wrap_nomor(h["nomor"])] for h in clone]))

    if ngambek:
        parts.append(rich_ui.rich_para(
            f"{tgemoji('warning', '⚠️')} "
            "<b>Si mark ngambek jir — silahkan cek ulang</b>"))
        parts.append(rich_ui.rich_data_table(
            ["Nomor"], [[wrap_nomor(h["nomor"])] for h in ngambek]))

    if error:
        parts.append(rich_ui.rich_para(
            f"{tgemoji('warning', '⚠️')} <b>Error</b>"))
        parts.append(rich_ui.rich_data_table(
            ["Nomor", "Alasan"],
            [[wrap_nomor(h["nomor"]),
              html.escape(str(h.get("alasan") or "-"))] for h in error]))

    if not hasil_list:
        parts.append(rich_ui.rich_para("<i>Belum ada hasil...</i>"))

    # Footer info
    parts.append(rich_ui.rich_info_table([
        [f"{tgemoji('clock', '⏱')} Durasi", f"{durasi:.2f}s"],
        [f"{tgemoji('info', 'ℹ️')} Versi", html.escape(str(versi_mark))],
        [f"{tgemoji('refresh', '🔄')} Total dicek",
         f"<b>{len(hasil_list)}</b>"],
    ]))
    if progress:
        parts.append(rich_ui.rich_para(
            f"{tgemoji('loading', '⏳')} " +
            rich_ui.rich_highlight(f"Sedang berjalan... ({progress})")))
    elif selesai:
        parts.append(rich_ui.rich_para(
            f"{tgemoji('success', '✅')} " +
            rich_ui.rich_highlight("<b>Selesai</b>")))
    else:
        parts.append(rich_ui.rich_para(
            f"{tgemoji('loading', '⏳')} <i>Sedang berjalan...</i>"))

    return "".join(parts)


def susun_pesan_dilewati(nomor_dilewati: list, batas: int) -> str:
    return (
        rich_ui.rich_h2(f"{tgemoji('noentry', '🚫')} NOMOR TIDAK DICEK") +
        rich_ui.rich_para(
            "Nomor berikut dilewati karena melebihi batas "
            f"<b>{batas}</b>:") +
        rich_ui.rich_data_table(
            ["Nomor"],
            [[f"<code>{html.escape(str(n))}</code>"] for n in nomor_dilewati])
    )


# ==================== AUTO BACKUP ====================

def buat_backup_zip() -> Path:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_path = BASE_DIR / f"backup_{ts}.zip"

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in BASE_DIR.rglob("*"):
            if not path.is_file():
                continue
            if "__pycache__" in path.parts:
                continue
            if path.suffix == ".zip":
                continue
            try:
                arcname = path.relative_to(BASE_DIR)
                zf.write(path, arcname)
            except Exception as e:
                logger.warning("Skip %s: %s", path, e)

    return zip_path


async def job_backup(context: ContextTypes.DEFAULT_TYPE):
    if not config.OWNER_ID:
        return
    try:
        zip_path = buat_backup_zip()
    except Exception as e:
        logger.error("Gagal bikin zip: %s", e)
        return
    try:
        with open(zip_path, "rb") as f:
            await context.bot.send_document(
                chat_id=int(config.OWNER_ID),
                document=f,
                filename=zip_path.name,
                caption=f"📦 Auto Backup\n🕐 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            )
        logger.info("Backup terkirim: %s", zip_path.name)
    except Exception as e:
        logger.error("Gagal kirim backup: %s", e)
    finally:
        try:
            zip_path.unlink()
        except Exception:
            pass


# ==================== FORCE JOIN ====================

async def cek_sudah_join(context: ContextTypes.DEFAULT_TYPE, user_id: int) -> list:
    belum = []
    for chat_id in config.FORCE_JOIN:
        try:
            member = await context.bot.get_chat_member(chat_id, user_id)
            status = getattr(member, "status", None)
            if status in ("left", "kicked", "banned"):
                belum.append(chat_id)
        except TelegramError as e:
            logger.warning("Gagal cek member di %s: %s", chat_id, e)
            belum.append(chat_id)
    return belum


def _link_join(chat_id) -> str:
    s = str(chat_id)
    if s.startswith("@"):
        return f"https://t.me/{s.lstrip('@')}"
    if s.startswith("-100"):
        return f"https://t.me/c/{s[4:]}"
    return f"https://t.me/{s}"


def buat_keyboard_force_join(belum_join: list):
    # Inline keyboard Telegram Bot API tidak menerima tag <tg-emoji>;
    # gunakan emoji Unicode pada label tombol.
    return _kb_ptb(spec_force_join(belum_join))


def teks_force_join(belum_join: list) -> str:
    return (
        rich_ui.rich_h2(f"{tgemoji('lock', '🔒')} VANTA • ACCESS GATE") +
        rich_ui.rich_para(
            f"{tgemoji('warning', '⚠️')} <i>Akses belum tersedia</i>") +
        rich_ui.rich_para("Selesaikan langkah berikut untuk melanjutkan:") +
        rich_ui.rich_checklist([
            f"{tgemoji('channel', '📢')} <code>{html.escape(str(c))}</code>"
            for c in belum_join
        ]) +
        rich_ui.rich_para(
            f"{tgemoji('success', '✅')} Setelah bergabung, "
            "tekan tombol <b>SUDAH JOIN</b>.")
    )


async def balas_rich(update, context, rich_html, keyboard=None,
                     keyboard_rich=None):
    """Kirim pesan: coba Rich Message dulu, fallback ke balas() biasa."""
    chat = update.effective_chat
    if chat and rich_ui.ada_tag_rich(rich_html):
        ok = await rich_ui.kirim_rich(config.BOT_TOKEN, chat.id, rich_html,
                                      keyboard_rich)
        if ok:
            return None
    return await balas(update, context, rich_ui.rich_ke_html(rich_html),
                       reply_markup=keyboard, parse_mode="HTML")


async def _edit_hasil(msg, rich_html):
    """Edit pesan hasil deteksi: coba rich, fallback ke HTML biasa."""
    if len(rich_html) <= 4000:
        ok = await rich_ui.edit_rich(config.BOT_TOKEN, msg.chat.id,
                                     msg.message_id, rich_html)
        if ok:
            return
    fb, _ = _customize_emojis(rich_ui.rich_ke_html(rich_html))
    try:
        await msg.edit_text(fb[:4000], parse_mode="HTML")
    except BadRequest as e:
        if not _entity_error(e):
            raise
        await msg.edit_text(_strip_custom_emoji(fb)[:4000], parse_mode="HTML")


async def cek_force_join_atau_kirim(update: Update,
                                     context: ContextTypes.DEFAULT_TYPE) -> bool:
    if not config.FORCE_JOIN:
        return True
    user = update.effective_user
    if is_owner(user.id):
        return True
    belum = await cek_sudah_join(context, user.id)
    if not belum:
        return True
    await balas_rich(update, context, teks_force_join(belum),
                     buat_keyboard_force_join(belum), spec_force_join(belum))
    return False


# ==================== VANTA CHECKER UI ====================
def tgemoji(key: str, fallback: str) -> str:
    """Ambil ID custom emoji dari pack berdasarkan karakter fallback."""
    emoji_map = getattr(config, "TG_EMOJI_MAP", {}) or {}
    emoji_id = str(emoji_map.get(fallback, "")).strip()
    if emoji_id.isdigit():
        return f'<tg-emoji emoji-id="{emoji_id}">{fallback}</tg-emoji>'
    return fallback


def teks_menu_awal(user, s):
    nama = html.escape(user.first_name or user.username or "kak")
    username = html.escape("@" + user.username if user.username else "belum diatur")
    status = "PREMIUM" if cek_tier(user.id) == "premium" else "STANDARD"
    return (
        rich_ui.rich_h2("🔻 V A N T A   C H E C K E R") +
        rich_ui.rich_para("<i>Control Center • Smart • Minimal • Secure</i>") +
        rich_ui.rich_para(
            f"{tgemoji('hello', '✨')} Selamat datang, <b>{nama}</b>") +
        rich_ui.rich_para(f"{tgemoji('profile', '👤')} <b>PROFILE</b>") +
        rich_ui.rich_info_table([
            ["Username", username],
            ["Telegram ID", f"<code>{user.id}</code>"],
            ["Membership",
             rich_ui.rich_highlight(f"<b>{status}</b>")],
        ]) +
        rich_ui.rich_para(f"{tgemoji('stats', '📊')} <b>YOUR ACTIVITY</b>") +
        rich_ui.rich_info_table([
            ["Total Detek", f"<b>{s['total']}</b>"],
            ["Detek hari ini", f"<b>{s['today']}</b>"],
        ]) +
        rich_ui.rich_para(
            f"{tgemoji('network', '🌐')} <b>NETWORK OVERVIEW</b>") +
        rich_ui.rich_info_table([
            ["Pengguna", f"<b>{s['global_users']}</b>"],
            ["Total aktivitas", f"<b>{s['global_detections']}</b>"],
        ]) +
        rich_ui.rich_para("<i>Pilih menu di bawah untuk melanjutkan.</i>")
    )


def teks_fitur():
    return (
        rich_ui.rich_h2(f"{tgemoji('menu', '🔷')} VANTA • MENU GUIDE") +
        rich_ui.rich_para("<i>Ringkasan perintah dan layanan bot</i>") +
        rich_ui.rich_para(f"{tgemoji('help', '📚')} <b>GENERAL</b>") +
        rich_ui.rich_checklist([
            "<code>/start</code> — buka dashboard",
            "<code>/help</code> — panduan bot",
            "<code>/cek</code> — deteksi nomor",
        ]) +
        rich_ui.rich_fold(
            f"{tgemoji('account', '💎')} ACCOUNT",
            rich_ui.rich_para("Status akun dan membership tersedia di "
                              "dashboard. Batas penggunaan mengikuti "
                              "konfigurasi akun.")) +
        rich_ui.rich_para(
            f"{tgemoji('support', '🛟')} Jika ada kendala, "
            "hubungi pengelola bot.") +
        rich_ui.rich_para("<i>Vanta Checker • Control Center</i>")
    )


def teks_panduan_cek():
    return (
        rich_ui.rich_h2(f"{tgemoji('detek', '🔍')} PANDUAN /cek") +
        rich_ui.rich_checklist([
            "<code>/cek +62881xxxx</code> — satu nomor",
            "<code>/cek +62881xxxx +62881xxxx +60112xxxx</code> "
            "— banyak nomor sekaligus",
            "Bisa juga multi-line, satu nomor per baris",
        ]) +
        rich_ui.rich_fold(
            "Contoh",
            rich_ui.rich_para("<code>/cek +628123456789</code>"))
    )


def teks_admin(user, s):
    prem = load_premium().get("users", {})
    ban = load_banned().get("users", {})
    return (
        rich_ui.rich_h2(f"{tgemoji('admin', '⚙️')} VANTA • OWNER CONSOLE") +
        rich_ui.rich_para("<i>Restricted access • Owner only</i>") +
        rich_ui.rich_para(f"{tgemoji('users', '👥')} <b>USER MANAGEMENT</b>") +
        rich_ui.rich_data_table(
            ["Perintah", "Fungsi"],
            [
                ["<code>/addprem ID</code>", "tambah membership"],
                ["<code>/delprem ID</code>", "hapus membership"],
                ["<code>/ban ID alasan</code>", "blokir pengguna"],
                ["<code>/unban ID</code>", "buka blokir"],
            ]) +
        rich_ui.rich_para(
            f"{tgemoji('broadcast', '📣')} <b>ANNOUNCEMENTS</b>") +
        rich_ui.rich_info_table([
            ["<code>/bc pesan</code>", "broadcast informasi"],
        ]) +
        rich_ui.rich_para(f"{tgemoji('stats', '📊')} <b>SYSTEM SNAPSHOT</b>") +
        rich_ui.rich_info_table([
            ["Premium", f"<b>{len(prem)}</b>"],
            ["Banned", f"<b>{len(ban)}</b>"],
        ]) +
        rich_ui.rich_para("<i>Kelola akses secara bertanggung jawab.</i>")
    )


# ==================== KEYBOARD ====================
# ── Spesifikasi tombol: SATU sumber untuk rich & fallback ──
# style valid untuk Rich Message: primary / success / danger.
# (Tidak ada tombol destruktif di bot ini -> danger tidak dipakai.)
# Fallback PTB (InlineKeyboardButton) mengabaikan style.
def spec_menu(user_id: int):
    rows = [[{"text": "🔍  DETEK", "callback_data": "detek",
              "style": "primary"}]]
    if is_owner(user_id):
        rows.append([{"text": "🛠️  OWNER COMMAND", "callback_data": "admin_panel",
                      "style": "primary"}])
    return rows


def spec_nav(user_id: int):
    """Navigasi kembali — dipakai layar Detek & Help."""
    rows = [[{"text": "🏠  DASHBOARD", "callback_data": "menu_awal",
              "style": "primary"}]]
    if is_owner(user_id):
        rows.append([{"text": "🛠️  OWNER COMMAND", "callback_data": "admin_panel",
                      "style": "primary"}])
    return rows


def spec_admin():
    return [[{"text": "🏠  DASHBOARD", "callback_data": "menu_awal",
               "style": "primary"}]]


def spec_force_join(belum_join: list):
    rows = []
    for chat_id in belum_join:
        label = chat_id if str(chat_id).startswith("@") else str(chat_id)
        rows.append([{"text": f"📢  JOIN {label}", "url": _link_join(chat_id),
                      "style": "primary"}])
    rows.append([{"text": "✅  SUDAH JOIN", "callback_data": "cek_join",
                  "style": "success"}])
    return rows


def _kb_ptb(spec):
    tombol = []
    for r in spec:
        baris = []
        for b in r:
            kw = {}
            if b.get("callback_data"):
                kw["callback_data"] = b["callback_data"]
            if b.get("url"):
                kw["url"] = b["url"]
            baris.append(InlineKeyboardButton(b["text"], **kw))
        tombol.append(baris)
    return InlineKeyboardMarkup(tombol)


def buat_keyboard_menu(user_id: int):
    return _kb_ptb(spec_menu(user_id))


def buat_keyboard_nav(user_id: int):
    return _kb_ptb(spec_nav(user_id))


def buat_keyboard_admin():
    return _kb_ptb(spec_admin())


# ==================== HANDLER ====================

@banned_guard
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await cek_force_join_atau_kirim(update, context):
        return

    user = update.effective_user
    s = get_stats(user.id)
    pesan = teks_menu_awal(user, s)
    keyboard = buat_keyboard_menu(user.id)

    logger.info(f"👤 /start oleh {user.id} - {user.username or user.first_name}")

    if config.START_PHOTO_URL:
        try:
            await balas_foto(update, context, config.START_PHOTO_URL,
                             rich_ui.rich_ke_html(pesan),
                             parse_mode="HTML", reply_markup=keyboard)
            return
        except Exception as e:
            logger.warning("Gagal kirim foto: %s", e)

    await balas_rich(update, context, pesan, keyboard, spec_menu(user.id))


@banned_guard
async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await cek_force_join_atau_kirim(update, context):
        return
    user = update.effective_user
    await balas_rich(update, context, teks_fitur(), buat_keyboard_nav(user.id),
                     spec_nav(user.id))


@banned_guard
@banned_guard
async def tombol_detek(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await aman_answer(query)

    user = update.effective_user
    if config.FORCE_JOIN and not is_owner(user.id):
        belum = await cek_sudah_join(context, user.id)
        if belum:
            await aman_answer(query, "🔒 Join dulu ya!", show_alert=True)
            return

    await kirim_atau_edit(query, teks_panduan_cek(),
                          buat_keyboard_nav(user.id), spec_nav(user.id))


@owner_only
@banned_guard
async def tombol_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await aman_answer(query)
    user = update.effective_user
    s = get_stats(user.id)
    await kirim_atau_edit(query, teks_admin(user, s), buat_keyboard_admin(),
                          spec_admin())


@banned_guard
async def tombol_menu_awal(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await aman_answer(query)

    user = update.effective_user
    if config.FORCE_JOIN and not is_owner(user.id):
        belum = await cek_sudah_join(context, user.id)
        if belum:
            await aman_answer(query, "🔒 Join dulu ya!", show_alert=True)
            return

    s = get_stats(user.id)
    await kirim_atau_edit(query, teks_menu_awal(user, s),
                          buat_keyboard_menu(user.id), spec_menu(user.id))


async def tombol_cek_join(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user = update.effective_user

    await aman_answer(query)

    if is_banned(user.id):
        await aman_answer(query, "🚫 Anda dibanned.", show_alert=True)
        return

    if not config.FORCE_JOIN or is_owner(user.id):
        await aman_answer(query, "✅ Udah join.", show_alert=True)
        return

    belum = await cek_sudah_join(context, user.id)
    if belum:
        await aman_answer(query, "❌ Kamu masih belum join semua.", show_alert=True)
        await kirim_atau_edit(query, teks_force_join(belum),
                              buat_keyboard_force_join(belum),
                              spec_force_join(belum))
        return

    try:
        await query.message.delete()
    except Exception:
        pass

    s = get_stats(user.id)
    pesan = teks_menu_awal(user, s)
    keyboard = buat_keyboard_menu(user.id)

    if config.START_PHOTO_URL:
        try:
            await context.bot.send_photo(
                chat_id=user.id,
                photo=config.START_PHOTO_URL,
                caption=rich_ui.rich_ke_html(pesan),
                parse_mode="HTML",
                reply_markup=keyboard,
            )
            return
        except Exception as e:
            logger.warning("Gagal kirim foto: %s", e)

    if not await rich_ui.kirim_rich(config.BOT_TOKEN, user.id, pesan,
                                    spec_menu(user.id)):
        fallback_html = rich_ui.rich_ke_html(pesan)
        try:
            await context.bot.send_message(
                chat_id=user.id,
                text=fallback_html,
                parse_mode="HTML",
                reply_markup=keyboard,
            )
        except BadRequest as e:
            # Fallback terakhir: plain text agar markup Rich/HTML yang tidak
            # didukung Telegram tidak membuat /start gagal total.
            logger.warning("HTML /start ditolak Telegram, kirim teks biasa: %s", e)
            plain = html.unescape(re.sub(r"<[^>]*>", "", fallback_html))
            plain = re.sub(r"[ \t]+\n", "\n", plain).strip() or "Vanta Checker"
            await context.bot.send_message(
                chat_id=user.id,
                text=plain[:4000],
                reply_markup=keyboard,
            )


async def _proses_cek(update, context, nomor_list, user, setting,
                      nomor_dilewati, batas, msg=None):
    async with _detect_semaphore:
        tier = setting["tier"]
        methods = setting["method"]
        delay = setting["bulk_delay"]
        total = len(nomor_list)

        mulai = time.time()
        hasil_list = []
        ngambek_counter = 0

        for i, nomor in enumerate(nomor_list, 1):
            try:
                h = await cek_satu_nomor_ringkas(nomor, methods)
            except Exception as e:
                h = {"nomor": nomor, "kategori": "error",
                     "cooldown_detik": None, "alasan": type(e).__name__}
            hasil_list.append(h)

            # Update hasil SETIAP nomor selesai dicek
            if msg:
                durasi = time.time() - mulai
                teks = susun_pesan(hasil_list, durasi, False,
                                   progress=f"{i}/{total}")
                try:
                    await _edit_hasil(msg, teks)
                except Exception:
                    pass

            # Adaptive backoff kalau ngambek numpuk
            if h["kategori"] == "ngambek":
                ngambek_counter += 1
            else:
                ngambek_counter = max(0, ngambek_counter - 1)

            actual_delay = delay + random.uniform(0, 0.5)
            if ngambek_counter >= 3:
                actual_delay += 2.0
            elif ngambek_counter >= 1:
                actual_delay += 0.5

            await asyncio.sleep(actual_delay)

        durasi = time.time() - mulai
        teks_akhir = susun_pesan(hasil_list, durasi, True)

        # ===== PESAN 1: hasil final =====
        if msg:
            try:
                await _edit_hasil(msg, teks_akhir)
            except Exception:
                pass
            fb_akhir, _ = _customize_emojis(rich_ui.rich_ke_html(teks_akhir))
            if len(fb_akhir) > 4000:
                sisa_teks = fb_akhir[4000:]
                while sisa_teks:
                    try:
                        await context.bot.send_message(
                            chat_id=user.id, text=sisa_teks[:4000],
                            parse_mode="HTML"
                        )
                    except Exception:
                        break
                    sisa_teks = sisa_teks[4000:]

        # ===== PESAN 2: nomor yang dilewati =====
        if nomor_dilewati:
            teks_dilewati = susun_pesan_dilewati(nomor_dilewati, batas)
            try:
                ok = await rich_ui.kirim_rich(config.BOT_TOKEN, user.id,
                                              teks_dilewati)
                if not ok:
                    fb_dilewati, _ = _customize_emojis(
                        rich_ui.rich_ke_html(teks_dilewati))
                    await context.bot.send_message(
                        chat_id=user.id, text=fb_dilewati, parse_mode="HTML"
                    )
            except Exception as e:
                logger.warning("Gagal kirim pesan dilewati: %s", e)

        tandai_cooldown(user.id)
        uname = user.username or user.first_name or str(user.id)
        update_stats(user.id, uname, len(hasil_list))

        logger.info(f"🔍 Deteksi oleh {user.id} ({uname}) - {len(hasil_list)} nomor ({tier})")


async def jalankan_cek(update: Update, context: ContextTypes.DEFAULT_TYPE, nomor_list: list):
    user = update.effective_user
    setting = ambil_setting(user.id)
    tier = setting["tier"]

    sisa = sisa_cooldown(user.id)
    if sisa > 0:
        await balas(update, context,
                    f"⏳ Sabar dikit ya.\n"
                    f"Cooldown kamu masih {detik_ke_teks(sisa)} lagi.\n\n"
                    f"Tier: {tier.capitalize()}")
        return

    nomor_list = [n for n in nomor_list if valid_nomor(n)]
    if not nomor_list:
        await balas(update, context, "❌ Gak ada nomor valid.")
        return

    max_bulk = setting["max_bulk"]
    nomor_dilewati = []
    if len(nomor_list) > max_bulk:
        nomor_dilewati = nomor_list[max_bulk:]
        nomor_list = nomor_list[:max_bulk]

    info_tier = f"[{tier.capitalize()}]" if tier == "premium" else ""
    msg = await balas(update, context,
                      f"⏳ Cek 0/{len(nomor_list)} nomor... {info_tier}".strip())

    tandai_cooldown(user.id)

    asyncio.create_task(
        _proses_cek(update, context, nomor_list, user, setting,
                    nomor_dilewati, max_bulk, msg)
    )


@banned_guard
async def cek_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await cek_force_join_atau_kirim(update, context):
        return

    args = context.args
    if not args:
        await balas_rich(update, context, teks_panduan_cek())
        return

    raw = " ".join(args)
    nomor_list = [n for n in re.split(r"[\s,]+", raw) if n.strip()]
    await jalankan_cek(update, context, nomor_list)


# ==================== COMMAND ADMIN ====================

@owner_only
@banned_guard
async def addprem_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args
    if not args:
        await balas(update, context, "Usage: /addprem <id>")
        return
    try:
        target = int(args[0])
    except ValueError:
        await balas(update, context, "ID harus angka.")
        return

    data = load_premium()
    if str(target) in data["users"]:
        await balas(update, context, f"✅ {target} udah premium dari dulu.")
        return

    data["users"][str(target)] = {
        "since": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "added_by": update.effective_user.id,
    }
    save_premium(data)
    await balas(update, context, f"✅ {target} sekarang Premium.")


@owner_only
@banned_guard
async def delprem_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args
    if not args:
        await balas(update, context, "Usage: /delprem <id>")
        return
    try:
        target = int(args[0])
    except ValueError:
        await balas(update, context, "ID harus angka.")
        return

    data = load_premium()
    if str(target) not in data["users"]:
        await balas(update, context, f"❌ {target} bukan premium.")
        return

    del data["users"][str(target)]
    save_premium(data)
    await balas(update, context, f"✅ Premium {target} dihapus.")


@owner_only
@banned_guard
async def ban_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args
    if not args:
        await balas(update, context, "Usage: /ban <id> <alasan>")
        return
    try:
        target = int(args[0])
    except ValueError:
        await balas(update, context, "ID harus angka.")
        return

    if is_owner(target):
        await balas(update, context, "❌ Gak bisa ban owner.")
        return

    alasan = " ".join(args[1:]) if len(args) > 1 else "tidak ada alasan"

    data = load_banned()
    data["users"][str(target)] = {
        "reason": alasan,
        "since": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "banned_by": update.effective_user.id,
    }
    save_banned(data)
    await balas(update, context, f"🚫 {target} dibanned.\nAlasan: {alasan}")


@owner_only
@banned_guard
async def unban_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args
    if not args:
        await balas(update, context, "Usage: /unban <id>")
        return
    try:
        target = int(args[0])
    except ValueError:
        await balas(update, context, "ID harus angka.")
        return

    data = load_banned()
    if str(target) not in data["users"]:
        await balas(update, context, f"❌ {target} gak dibanned.")
        return

    del data["users"][str(target)]
    save_banned(data)
    await balas(update, context, f"✅ {target} di-unban.")


@owner_only
@banned_guard
async def bc_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args
    if not args:
        await balas(update, context,
                    "Usage: /bc <pesan>\n\n"
                    "Contoh:\n/bc Halo semua, bot maintenance jam 12 malam ya.")
        return

    pesan = " ".join(args)

    data = load_stats()
    users = list(data.get("users", {}).keys())
    if not users:
        await balas(update, context, "❌ Belum ada user yang pernah pakai bot.")
        return

    msg = await balas(update, context, f"📢 Broadcast ke {len(users)} user...")

    berhasil = 0
    gagal = 0
    for uid in users:
        try:
            pesan_out, changed = _customize_emojis(pesan)
            await context.bot.send_message(
                chat_id=int(uid), text=pesan_out,
                parse_mode="HTML" if changed else None
            )
            berhasil += 1
        except Exception as e:
            gagal += 1
            logger.warning(f"Gagal kirim ke {uid}: {e}")
        await asyncio.sleep(0.05)

    try:
        selesai = (
            rich_ui.rich_h2(
                f"{tgemoji('broadcast', '📣')} BROADCAST SELESAI") +
            rich_ui.rich_info_table([
                [f"{tgemoji('success', '✅')} Berhasil",
                 f"<b>{berhasil}</b>"],
                [f"{tgemoji('failed', '❌')} Gagal", f"<b>{gagal}</b>"],
                [f"{tgemoji('users', '👥')} Total",
                 f"<b>{len(users)}</b>"],
            ])
        )
        await _edit_hasil(msg, selesai)
    except Exception:
        pass

    logger.info(f"📢 Broadcast oleh owner - {berhasil} berhasil, {gagal} gagal")


# ==================== ERROR HANDLER ====================

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    err = context.error
    pesan = str(err)

    if "Query is too old" in pesan or "query id is invalid" in pesan:
        logger.warning("⚠️ Query too old (diabaikan)")
        return
    if "Message is not modified" in pesan:
        return
    if "Message to delete not found" in pesan:
        return

    logger.error("❌ Error: %s", err)


# ==================== MAIN ====================

async def _post_init(app):
    await rich_ui.deteksi_rich(config.BOT_TOKEN)


def main():
    if not config.BOT_TOKEN or config.BOT_TOKEN == "ISI_TOKEN_BOT_BARU_DI_SINI":
        print("❌ Set BOT_TOKEN di config.py dulu!")
        return

    app = ApplicationBuilder().token(config.BOT_TOKEN).post_init(_post_init).build()

    # Command user
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("cek", cek_cmd))

    # Command admin
    app.add_handler(CommandHandler("addprem", addprem_cmd))
    app.add_handler(CommandHandler("delprem", delprem_cmd))
    app.add_handler(CommandHandler("ban", ban_cmd))
    app.add_handler(CommandHandler("unban", unban_cmd))
    app.add_handler(CommandHandler("bc", bc_cmd))

    # Tombol inline
    app.add_handler(CallbackQueryHandler(tombol_detek, pattern="^detek$"))
    app.add_handler(CallbackQueryHandler(tombol_admin, pattern="^admin_panel$"))
    app.add_handler(CallbackQueryHandler(tombol_menu_awal, pattern="^menu_awal$"))
    app.add_handler(CallbackQueryHandler(tombol_cek_join, pattern="^cek_join$"))

    # Error handler
    app.add_error_handler(error_handler)

    # Auto backup
    if config.BACKUP_ENABLED and config.OWNER_ID and app.job_queue:
        interval_detik = config.BACKUP_INTERVAL_HOURS * 3600
        first_delay = getattr(config, "BACKUP_FIRST_DELAY", 30)
        app.job_queue.run_repeating(
            job_backup,
            interval=interval_detik,
            first=first_delay,
            name="auto_backup",
        )
        print(f"📦 Auto backup aktif tiap {config.BACKUP_INTERVAL_HOURS} jam.")

    print("✅ Bot jalan... Tekan Ctrl+C untuk stop.")
    app.run_polling()


if __name__ == "__main__":
    main()
